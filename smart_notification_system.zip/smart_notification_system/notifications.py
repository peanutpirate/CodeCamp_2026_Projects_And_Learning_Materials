from datetime import datetime


class Notification:

    def __init__(self, message):
        self.message = message
        self.created_at = datetime.now()

    def send(self):
        pass

    def __str__(self):
        return f"Bildirim: {self.message} | Oluşturulma: {self.created_at}"

    def __len__(self):
        return len(self.message)


class EmailNotification(Notification):

    def send(self):
        print(f"Email gönderildi: {self.message}")


class SMSNotification(Notification):

    def send(self):
        print(f"SMS gönderildi: {self.message}")


class PushNotification(Notification):

    def send(self):
        print(f"Push bildirimi gönderildi: {self.message}")