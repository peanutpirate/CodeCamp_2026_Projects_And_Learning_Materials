import random
from datetime import datetime
from notifications import EmailNotification, SMSNotification, PushNotification

def get_random_notification():
    mesajlar = [
        "Sisteme giriş yapıldı",
        "Yeni bir mesajınız var",
        "Ödeme işleminiz onaylandı",
        "Şifreniz güncellendi",
        "Haftalık raporunuz hazır"
    ]
    
    secilen_mesaj = random.choice(mesajlar)
    # Bildirim zamanını burada da görebilmek için alıyoruz
    su_an = datetime.now().strftime("%H:%M")
    tam_mesaj = f"{secilen_mesaj} (Saat: {su_an})"
    
    # Sınıf isimlerini listeye ekledik
    bildirim_tipleri = [EmailNotification, SMSNotification, PushNotification]
    secilen_tip = random.choice(bildirim_tipleri)
    
    # Yeni mesaj içeriğiyle nesneyi oluşturuyoruz
    return secilen_tip(tam_mesaj)