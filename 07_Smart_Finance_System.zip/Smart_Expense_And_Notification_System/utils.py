# Bu dosya veriyi üretir ama analiz yapmaz. 

import random
from datetime import datetime

def get_user_expenses():
    expenses = []

    while True:
        try:
            amount = float(input("Harcama tutarını girin (bitirmek için 0): "))

            if amount == 0:
                break

            category = input("Kategori girin: ")
            date = datetime.now().date()

            expenses.append((amount, category, date))

        except ValueError:
            print("Lütfen geçerli bir sayı giriniz.")

    return expenses

def generate_random_notification():
    messages = [
        "Bütçe limitine yaklaştınız!",
        "Harcama limiti aşıldı!",
        "Günlük harcama raporu hazır.",
        "Yeni bir harcama eklendi."
    ]

    message = random.choice(messages)
    time = datetime.now().strftime("%H:%M")

    return f"{message} ({time})"