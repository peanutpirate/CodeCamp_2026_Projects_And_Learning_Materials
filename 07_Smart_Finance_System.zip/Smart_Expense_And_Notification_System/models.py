from datetime import datetime


class Expense:
    """
    Tek bir harcamayı temsil eder.
    """

    def __init__(self, amount, category, date=None):
        self.amount = amount
        self.category = category
        # Tarih verilmezse bugünün tarihi atanır
        self.date = date if date else datetime.now().date()

    def __str__(self):
        return f"{self.category} - {self.amount} TL ({self.date})"


class Budget:
    """
    Kullanıcının bütçesini ve harcamalarını yönetir.
    """

    def __init__(self, limit):
        self.limit = limit
        self.expenses = []

    def add_expense(self, expense):
        """
        Yeni bir harcamayı listeye ekler.
        """
        self.expenses.append(expense)

    def total_expense(self):
        """
        Toplam harcamayı hesaplar.
        """
        total = 0
        for expense in self.expenses:
            total += expense.amount
        return total

    def average_expense(self):
        """
        Ortalama harcamayı hesaplar.
        """
        if len(self.expenses) == 0:
            return 0
        return self.total_expense() / len(self.expenses)

    def is_limit_exceeded(self):
        """
        Bütçe limiti aşıldı mı?
        """
        return self.total_expense() > self.limit