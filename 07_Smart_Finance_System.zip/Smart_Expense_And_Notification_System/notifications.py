class Notification:
    """
    Base Notification Class
    """

    def __init__(self, message):
        if not message or message.strip() == "":
            raise ValueError("Bildirim mesajı boş olamaz.")
        self.message = message

    def send(self):
        """
        Alt sınıflar override edecek.
        """
        pass

    def __str__(self):
        return f"Bildirim: {self.message}"

class EmailNotification(Notification):

    def send(self):
        print(f"Email gönderildi: {self.message}")
        
class SMSNotification(Notification):

    def send(self):
        print(f"SMS gönderildi: {self.message}")
